<?php
/*
Hi I am a plugin developer. The plugin is still in beta. If you have any problems, please give me feedback: https://www.facebook.com/profile.php?id=100071316150096 
*/
#Tên : Duy Onichan, Biệt danh : pmmdst, Plugin hiện còn trong giai đoạn Beta. Nếu bạn có bất cứ vấn đề gì, hãy góp ý kiến tại: https://www.facebook.com/profile.php?id=100071316150096

namespace BitcoinAPI;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\PluginBase;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;

use pocketmine\utils\Config;

use pocketmine\event\player\PlayerJoinEvent;

use BitcoinAPI\BitcoinChangeEvent;
use BitcoinAPI\BitcoinEvent;

class Bitcoin extends PluginBase implements Listener {
  
  public function onEnable(){
    $this->getLogger()->info("BitcoinAPI Beta v0.0.2 đã bật, hãy trải nghiệm ngay!");
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->bitcoin = new Config($this->getDataFolder() . "bitcoin.yml", Config::YAML);
  }
  
  public function onDisable(){
    $this->getLogger()->info("BitcoinAPI Beta v0.0.2 đã tắt...");
  }
  
#----------------------------------------------------------------------------------------
  
  public function onJoin(PlayerJoinEvent $event){
    $player = $event->getPlayer();
    if(!$this->bitcoin->exists($player->getName())){
      $this->bitcoin->set($player->getName(), 0);
      $this->bitcoin->save();
      $this->getServer()->getPluginManager()->callEvent(new BitcoinChangeEvent($this, $player));
    }
  }
  
  public function reduceBitcoin($player, $bitcoin){
    if($player instanceof Player){
      if(is_numeric($bitcoin)){
         $this->bitcoin->set($player->getName(), ($this->bitcoin->get($player->getName()) - $bitcoin));
         $this->getServer()->getPluginManager()->callEvent(new BitcoinChangeEvent($this, $player));
      }
    }
  }
  
  public function addBitcoin($player, $bitcoin){
    if($player instanceof Player){
      if(is_numeric($bitcoin)){
         $this->bitcoin->set($player->getName(), ($this->bitcoin->get($player->getName()) + $bitcoin));
         $this->getServer()->getPluginManager()->callEvent(new BitcoinChangeEvent($this, $player));
      }
    }
  }
  
  public function myBitcoin($player){
    if($player instanceof Player){
      
      return ($this->bitcoin->get($player->getName()));
    }
  }
  
  public function getAllBitcoin(){
    return $this->bitcoin->getAll();
  }
  
#----------------------------------------------------------------------------------------
  
  public function onCommand(CommandSender $sender, Command $cmd, String $label, array $args): bool{
    switch($cmd->getName()){
      case "mybitcoin":
        if($sender instanceof Player){
          $bitcoin = $this->myBitcoin($sender);
          $sender->sendMessage("§b§l•§6 Số§e Bitcoin§6 của bạn:§e " . $bitcoin);
        }else{
          $sender->sendMessage("Yêu cầu : Sử dụng lệnh trong game!");
        }
        break;
        
        case "setbitcoin":
          if($sender instanceof Player){
            if($sender->hasPermission("setbitcoin.pmmdst")){
              if(isset($args[0])){
                if(isset($args[1])){
                  $player = $this->getServer()->getPlayer($args[0]);
                  if(!is_numeric($args[1])){
                    $sender->sendMessage("§b§l•§6 Lỗi : Kí tự phải là 1 chữ số!");
                    return true;
                  }
                  if(!$player instanceof Player){
                    $sender->sendMessage("§b§l•§6 Người chơi§a " . $args[0] . " §6không hoạt động!");
                    return true;
                  }
                  
                  $this->bitcoin->set($player->getName(), $args[1]);
                  $this->bitcoin->save();
                  $sender->sendMessage("§b§l•§6 Thành công chỉnh số §eBitcoin §6của người chơi§a " . $args[0] . " §6thành§e " . $args[1]);
                  $player->sendMessage("§b§l•§6 Số §eBitcoin§6 của bạn được chỉnh thành§e " . $args[1]);
                  $this->getServer()->getPluginManager()->callEvent(new BitcoinChangeEvent($this, $player));
                }else{
                  $sender->sendMessage("§b§l•§6 Lệnh: §e/setbitcoin {người chơi} {số lượng}");
                }
              }else{
                $sender->sendMessage("§b§l•§6 Lệnh: §e/setbitcoin {người chơi} {số lượng}");
              }
            }
          }else{
            $sender->sendMessage("Yêu cầu : Sử dụng lệnh trong game!");
          }
          break;
          
          case "topbitcoin":
            $bitcoinall = $this->getAllBitcoin();
            arsort($bitcoinall);
            $bitcoinall = array_slice($bitcoinall, 0, 9);
            $top = 1;
            foreach($bitcoinall as $name => $count){
              $sender->sendMessage("§b§l•§6 Xếp hạng " . $top . "§6§l Thuộc về người chơi§a " . $name . "§6§l với§e " . $count . " Bitcoin");
              $top++;
            }
            break;
            
            case "paybitcoin":
              if($sender instanceof Player){
                if(isset($args[0])){
                  if(isset($args[1])){
                    $player2 = $this->getServer()->getPlayer($args[0]);
                    $bitcoin = $this->myBitcoin($sender);
                    if(!$player2 instanceof Player){
                      $sender->sendMessage("§b§l•§6 Người chơi§a " . $args[0] . " §6không hoạt động!");
                      return true;
                    }
                    if(!is_numeric($args[1])){
                      $sender->sendMessage("§b§l•§6Yêu cầu : Kí tự phải là 1 chữ số");
                      return true;
                    }
                    if($args[0] === $sender->getName()){
                      $sender->sendMessage("§b§l•§6 Không thể tự trao §eBitcoin§6 cho bản thân!");
                      return true;
                    }
                    if($bitcoin >= $args[1]){
                      $this->reduceBitcoin($sender, $args[1]);
                      $this->addBitcoin($player2, $args[1]);
                      $sender->sendMessage("§b§l•§6 Thành công trao§e " . $args[1] . " §e§lBitcoin §6cho§a " . $args[0]);
                      $player2->sendMessage("§b§l•§6 Người chơi§a " . $sender->getName() . " §6đã trao cho bạn§e " . $args[1] . " Bitcoin!");
                    }else{
                      $sender->sendMessage("§b§l•§6 Lỗi : Không đủ số Bitcoin!");
                      return true;
                    }
                  }else{
                    $sender->sendMessage("§b§l•§6 Lệnh: §e/paybitcoin {người chơi} {số lượng}");
                  }
                }else{
                  $sender->sendMessage("§b§l•§6 Lệnh: §e/paybitcoin {người chơi} {số lượng}");
                }
              }else{
                $sender->sendMessage("Yêu cầu : Sử dụng lệnh trong game!");
              }
              break;
    }
    return true;
  }
}